# omni-food
Created an Responsive web page using CSS3, HTML5 and JavaScript called Omnifood

![ezgif com-video-to-gif](https://github.com/sukumar0/omni-food/assets/87295479/211496d7-f43d-4bac-a63d-a7fae79a77da)


![](images/omni1.PNG)
![](images/omni2.PNG)
![](images/omni3.PNG)
![](images/omni4.PNG)
![](images/omni5.PNG)
![](images/omni6.PNG)
![](images/omni7.PNG)
![](images/omni8.PNG)
